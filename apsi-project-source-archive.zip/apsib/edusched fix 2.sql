-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 23 Jan 2026 pada 03.05
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `edusched`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `file_soal`
--

CREATE TABLE `file_soal` (
  `id_soal` varchar(6) NOT NULL,
  `id_jadwal` int(6) NOT NULL,
  `user_id` varchar(6) NOT NULL,
  `deskripsi` varchar(150) NOT NULL,
  `nama_file` varchar(150) NOT NULL,
  `waktu_unggah` timestamp NOT NULL DEFAULT current_timestamp(),
  `path_file` varchar(100) NOT NULL,
  `tipe_file` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `file_soal`
--

INSERT INTO `file_soal` (`id_soal`, `id_jadwal`, `user_id`, `deskripsi`, `nama_file`, `waktu_unggah`, `path_file`, `tipe_file`) VALUES
('597085', 3332, 'A01', '3', 'kelas 3', '2026-01-23 02:03:50', '1769133830_P12 - TOPSIS - Rumus.pdf', 'pdf');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jadwal_ulangan`
--

CREATE TABLE `jadwal_ulangan` (
  `id_jadwal` int(6) NOT NULL,
  `id_soal` varchar(6) NOT NULL,
  `user_id` varchar(6) NOT NULL,
  `kelas` varchar(10) NOT NULL,
  `mata_pelajaran` varchar(40) NOT NULL,
  `status_pekerjaan` enum('not_started','in_progress','completed') DEFAULT NULL,
  `detail_ulangan` varchar(200) DEFAULT NULL,
  `tanggal_ulangan` date DEFAULT NULL,
  `sekolah` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `jadwal_ulangan`
--

INSERT INTO `jadwal_ulangan` (`id_jadwal`, `id_soal`, `user_id`, `kelas`, `mata_pelajaran`, `status_pekerjaan`, `detail_ulangan`, `tanggal_ulangan`, `sekolah`) VALUES
(3326, '', 'A01', 'Kelas 1', 'Bahasa Indonesia', NULL, NULL, NULL, 'Immanuel'),
(3327, '', '', 'Kelas 1', 'Mapel 2', NULL, NULL, NULL, 'Immanuel'),
(3328, '', '', 'Kelas 1', 'Mapel 3', NULL, NULL, NULL, 'Immanuel'),
(3329, '', 'A01', 'Kelas 2', 'Bahasa Indonesia', 'in_progress', 'BI kelas 2\n', '2026-01-09', 'Immanuel'),
(3330, '', '', 'Kelas 2', 'Mapel 2', NULL, NULL, NULL, 'Immanuel'),
(3331, '', '', 'Kelas 2', 'Mapel 3', NULL, NULL, NULL, 'Immanuel'),
(3332, '', 'A01', 'Kelas 3', 'Bahasa Indonesia', 'completed', 'BI kelas 3', '2026-01-13', 'Immanuel'),
(3333, '', '', 'Kelas 3', 'Mapel 2', NULL, NULL, NULL, 'Immanuel'),
(3334, '', '', 'Kelas 3', 'Mapel 3', NULL, NULL, NULL, 'Immanuel'),
(3335, '', '', 'Kelas 4', 'Bahasa Indonesia', NULL, NULL, NULL, 'Immanuel'),
(3336, '', '', 'Kelas 4', 'Mapel 2', NULL, NULL, NULL, 'Immanuel'),
(3337, '', '', 'Kelas 4', 'Mapel 3', NULL, NULL, NULL, 'Immanuel'),
(3338, '', '', 'Kelas 5', 'Bahasa Indonesia', NULL, NULL, NULL, 'Immanuel'),
(3339, '', '', 'Kelas 5', 'Mapel 2', NULL, NULL, NULL, 'Immanuel'),
(3340, '', '', 'Kelas 5', 'Mapel 3', NULL, NULL, NULL, 'Immanuel'),
(3341, '', '', 'Kelas 6', 'Bahasa Indonesia', NULL, NULL, NULL, 'Immanuel'),
(3342, '', '', 'Kelas 6', 'Mapel 2', NULL, NULL, NULL, 'Immanuel'),
(3343, '', '', 'Kelas 6', 'Mapel 3', NULL, NULL, NULL, 'Immanuel'),
(3344, '', '', 'Kelas 1', 'Mapel 4', NULL, NULL, NULL, 'Immanuel'),
(3345, '', '', 'Kelas 2', 'Mapel 4', NULL, NULL, NULL, 'Immanuel'),
(3346, '', '', 'Kelas 3', 'Mapel 4', NULL, NULL, NULL, 'Immanuel'),
(3347, '', '', 'Kelas 4', 'Mapel 4', NULL, NULL, NULL, 'Immanuel'),
(3348, '', '', 'Kelas 5', 'Mapel 4', NULL, NULL, NULL, 'Immanuel'),
(3349, '', '', 'Kelas 6', 'Mapel 4', NULL, NULL, NULL, 'Immanuel'),
(3350, '', '', 'Kelas 1', 'Mapel 5', NULL, NULL, NULL, 'Immanuel'),
(3351, '', '', 'Kelas 2', 'Mapel 5', NULL, NULL, NULL, 'Immanuel'),
(3352, '', '', 'Kelas 3', 'Mapel 5', NULL, NULL, NULL, 'Immanuel'),
(3353, '', '', 'Kelas 4', 'Mapel 5', NULL, NULL, NULL, 'Immanuel'),
(3354, '', '', 'Kelas 5', 'Mapel 5', NULL, NULL, NULL, 'Immanuel'),
(3355, '', '', 'Kelas 6', 'Mapel 5', NULL, NULL, NULL, 'Immanuel'),
(3356, '', '', 'Kelas 1', 'Mapel 6', NULL, NULL, NULL, 'Immanuel'),
(3357, '', '', 'Kelas 2', 'Mapel 6', NULL, NULL, NULL, 'Immanuel'),
(3358, '', '', 'Kelas 3', 'Mapel 6', NULL, NULL, NULL, 'Immanuel'),
(3359, '', '', 'Kelas 4', 'Mapel 6', NULL, NULL, NULL, 'Immanuel'),
(3360, '', '', 'Kelas 5', 'Mapel 6', NULL, NULL, NULL, 'Immanuel'),
(3361, '', '', 'Kelas 6', 'Mapel 6', NULL, NULL, NULL, 'Immanuel');

-- --------------------------------------------------------

--
-- Struktur dari tabel `log_perubahan`
--

CREATE TABLE `log_perubahan` (
  `id_perubahan` int(11) NOT NULL,
  `user_id` varchar(6) NOT NULL,
  `modul` varchar(50) NOT NULL,
  `aksi` enum('CREATE','UPDATE','DELETE') NOT NULL,
  `detail_perubahan` varchar(255) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `log_perubahan`
--

INSERT INTO `log_perubahan` (`id_perubahan`, `user_id`, `modul`, `aksi`, `detail_perubahan`, `waktu`) VALUES
(447, 'A01', 'User Management', 'CREATE', 'Menambahkan user Davent (ID: G01)', '2026-01-19 11:11:55'),
(448, 'A01', 'User Management', 'UPDATE', 'Update user Davent (nama: Davent → Daven, username: Davent → Daven)', '2026-01-19 11:12:10'),
(449, 'G01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 2 (Immanuel) | Tanggal: - → 20 Jan 2026 | Status:  → not_started | Deskripsi diubah', '2026-01-19 11:16:22'),
(450, 'G01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 3 (Immanuel) | Tanggal: - → 28 Jan 2026 | Status:  → completed', '2026-01-19 11:17:02'),
(451, 'G01', 'Files', 'CREATE', 'Upload file: IULANGAN', '2026-01-19 11:17:29'),
(452, 'A01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 1 (Immanuel) | Tanggal: 20 Jan 2026 → - | Status: in_progress →  | Deskripsi diubah', '2026-01-19 11:18:45'),
(453, 'A01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 2 (Immanuel) | Tanggal: 20 Jan 2026 → - | Status: not_started →  | Deskripsi diubah', '2026-01-19 11:18:46'),
(454, 'A01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 3 (Immanuel) | Tanggal: 28 Jan 2026 → - | Status: completed → ', '2026-01-19 11:18:47'),
(455, 'A01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 1 (Immanuel) | Tanggal: - → 20 Jan 2026 | Status:  → not_started | Deskripsi diubah', '2026-01-19 11:19:49'),
(456, 'G01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 1 (Immanuel) | Status: not_started → in_progress', '2026-01-19 11:20:36'),
(457, 'A01', 'User Management', 'CREATE', 'Menambahkan user Mars (ID: G02)', '2026-01-19 11:21:22'),
(458, 'A01', 'Profile', 'UPDATE', 'Nama: Wendy S → Wendy | Username: Wendy S → Wendy', '2026-01-19 11:22:28'),
(459, 'A01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 2 (Immanuel) | Tanggal: - → 22 Jan 2026 | Status:  → not_started | Deskripsi diubah', '2026-01-19 11:23:12'),
(460, 'G01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 2 (Immanuel) | Status: not_started → in_progress', '2026-01-19 11:23:52'),
(461, 'G01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 2 (Immanuel) | Status: in_progress → completed', '2026-01-19 11:25:52'),
(462, 'G01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 2 (Immanuel) | Tanggal: 22 Jan 2026 → - | Status: completed →  | Deskripsi diubah', '2026-01-19 11:29:21'),
(463, 'G01', 'Profile', 'UPDATE', 'Password diubah', '2026-01-19 11:30:42'),
(464, 'A01', 'Files', 'CREATE', 'Upload file: 3333ss', '2026-01-22 15:15:45'),
(465, 'A01', 'Files', 'DELETE', 'Menghapus file: IULANGAN', '2026-01-22 15:16:18'),
(466, 'A01', 'Files', 'CREATE', 'Upload file: aaa', '2026-01-22 15:31:44'),
(467, 'A01', 'Files', 'CREATE', 'Upload file: ggggs99', '2026-01-22 15:32:16'),
(468, 'A01', 'Files', 'DELETE', 'Menghapus file: ggggs99', '2026-01-22 15:42:00'),
(469, 'A01', 'Files', 'DELETE', 'Menghapus file: 3333ss', '2026-01-22 15:42:08'),
(470, 'A01', 'Schedule', 'UPDATE', 'Mengubah nama mapel di sekolah Immanuel dari Mapel 2 menjadi Bahasa Indonesia', '2026-01-22 15:42:24'),
(471, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Bahasa Indonesia - Kelas 2 (Immanuel) | Tanggal: - → 15 Jan 2026 | Status:  → not_started | Deskripsi diubah', '2026-01-22 15:42:38'),
(472, 'A01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 3 (Immanuel) | Tanggal: - → 15 Jan 2026 | Status:  → completed | Deskripsi diubah', '2026-01-22 15:42:51'),
(473, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Bahasa Indonesia - Kelas 1 (Immanuel) | Tanggal: - → 07 Jan 2026 | Status:  → in_progress | Deskripsi diubah', '2026-01-22 15:43:53'),
(474, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Mapel 4 - Kelas 1 (Immanuel) | Tanggal: - → 01 Jan 2026 | Status:  → not_started | Deskripsi diubah', '2026-01-22 15:44:03'),
(475, 'A01', 'Files', 'DELETE', 'Menghapus file: aaa', '2026-01-22 15:44:23'),
(476, 'A01', 'Files', 'DELETE', 'Menghapus file: meme', '2026-01-22 15:44:24'),
(477, 'A01', 'Files', 'DELETE', 'Menghapus file: ggg', '2026-01-22 15:44:26'),
(478, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Bahasa Indonesia - Kelas 1 (Immanuel) | Tanggal: 07 Jan 2026 → - | Status: in_progress →  | Deskripsi diubah', '2026-01-22 15:53:15'),
(479, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Bahasa Indonesia - Kelas 2 (Immanuel) | Tanggal: 15 Jan 2026 → - | Status: not_started →  | Deskripsi diubah', '2026-01-22 15:53:18'),
(480, 'A01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 3 (Immanuel) | Tanggal: 15 Jan 2026 → - | Status: completed →  | Deskripsi diubah', '2026-01-22 15:53:20'),
(481, 'A01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 1 (Immanuel) | Tanggal: 20 Jan 2026 → - | Status: in_progress →  | Deskripsi diubah', '2026-01-22 15:53:22'),
(482, 'A01', 'Files', 'CREATE', 'Upload file: aa', '2026-01-22 15:55:57'),
(483, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Mapel 4 - Kelas 1 (Immanuel) | Status: not_started → completed', '2026-01-22 16:12:21'),
(484, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Mapel 4 - Kelas 1 (Immanuel) | Status: completed → not_started', '2026-01-22 16:12:26'),
(485, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Mapel 4 - Kelas 1 (Immanuel) | Tanggal: 01 Jan 2026 → - | Status: not_started →  | Deskripsi diubah', '2026-01-22 16:12:37'),
(486, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Bahasa Indonesia - Kelas 1 (Immanuel) | Tanggal: - → 10 Jan 2026 | Status:  → not_started | Deskripsi diubah', '2026-01-22 16:12:47'),
(487, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Bahasa Indonesia - Kelas 1 (Immanuel) | Tanggal: 10 Jan 2026 → - | Status: not_started →  | Deskripsi diubah', '2026-01-22 16:18:55'),
(488, 'A01', 'Files', 'DELETE', 'Menghapus file: aa', '2026-01-22 16:19:00'),
(489, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Bahasa Indonesia - Kelas 1 (Immanuel) | Tanggal: - → 10 Jan 2026 | Status:  → not_started | Deskripsi diubah', '2026-01-22 16:19:16'),
(490, 'A01', 'Files', 'CREATE', 'Upload file: dd', '2026-01-22 16:25:02'),
(491, 'A01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 3 (Immanuel) | Tanggal: - → 09 Jan 2026 | Status:  → not_started | Deskripsi diubah', '2026-01-22 16:41:09'),
(492, 'A01', 'Files', 'CREATE', 'Upload file: nn', '2026-01-22 16:41:22'),
(493, 'A01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 2 (Immanuel) | Tanggal: - → 16 Jan 2026 | Status:  → not_started | Deskripsi diubah', '2026-01-22 16:41:39'),
(494, 'A01', 'Files', 'CREATE', 'Upload file: PPAP', '2026-01-22 16:41:50'),
(495, 'A01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 2 (Immanuel) | Tanggal: 16 Jan 2026 → - | Status: completed →  | Deskripsi diubah', '2026-01-22 16:47:57'),
(496, 'A01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 2 (Immanuel) | Tanggal: - → 14 Jan 2026 | Status:  → completed | Deskripsi diubah', '2026-01-22 16:48:04'),
(497, 'A01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 2 (Immanuel) | Tanggal: 14 Jan 2026 → - | Status: completed →  | Deskripsi diubah', '2026-01-22 16:48:50'),
(498, 'A01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 2 (Immanuel) | Tanggal: - → 08 Jan 2026 | Status:  → completed | Deskripsi diubah', '2026-01-22 16:49:01'),
(499, 'A01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 2 (Immanuel) | Tanggal: 08 Jan 2026 → - | Status: completed →  | Deskripsi diubah', '2026-01-22 16:56:26'),
(500, 'A01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 2 (Immanuel) | Tanggal: - → 15 Jan 2026 | Status:  → completed | Deskripsi diubah', '2026-01-22 16:56:34'),
(501, 'A01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 2 (Immanuel) | Tanggal: 15 Jan 2026 → - | Status: completed →  | Deskripsi diubah', '2026-01-22 16:56:37'),
(502, 'A01', 'Schedule', 'CREATE', 'Menambahkan jadwal baru untuk sekolah sss (3 kelas, 3 mapel)', '2026-01-22 16:56:44'),
(503, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Mapel 2 - Kelas 1 (sss) | Tanggal: - → 25 Jan 2026 | Status:  → not_started | Deskripsi diubah', '2026-01-22 16:57:28'),
(504, 'A01', 'Files', 'CREATE', 'Upload file: ss', '2026-01-22 16:57:40'),
(505, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Mapel 2 - Kelas 3 (sss) | Tanggal: - → 03 Jan 2026 | Status:  → not_started | Deskripsi diubah', '2026-01-22 16:58:46'),
(506, 'A01', 'Files', 'CREATE', 'Upload file: 76g86f', '2026-01-22 16:58:57'),
(507, 'A01', 'Schedule', 'UPDATE', 'Update jadwal MTK - Kelas 2 (Immanuel) | Tanggal: - → 08 Jan 2026 | Status:  → not_started | Deskripsi diubah', '2026-01-23 01:38:08'),
(508, 'A01', 'Files', 'DELETE', 'Menghapus file: 76g86f', '2026-01-23 01:38:33'),
(509, 'A01', 'Files', 'DELETE', 'Menghapus file: ss', '2026-01-23 01:38:35'),
(510, 'A01', 'Files', 'DELETE', 'Menghapus file: PPAP', '2026-01-23 01:38:37'),
(511, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Mapel 1 - Kelas 2 (sss) | Tanggal: - → 15 Jan 2026 | Status:  → not_started | Deskripsi diubah', '2026-01-23 01:38:59'),
(512, 'A01', 'Files', 'CREATE', 'Upload file: 43', '2026-01-23 01:39:19'),
(513, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Mapel 1 - Kelas 1 (sss) | Tanggal: - → 21 Jan 2026 | Status:  → not_started | Deskripsi diubah', '2026-01-23 01:41:01'),
(514, 'A01', 'Files', 'CREATE', 'Upload file: 111', '2026-01-23 01:41:15'),
(515, 'A01', 'Schedule', 'UPDATE', 'Mengubah nama mapel di sekolah sss dari Mapel 1 menjadi Mapel 1dd', '2026-01-23 01:42:29'),
(516, 'A01', 'Schedule', 'CREATE', 'Menambahkan jadwal baru untuk sekolah aa (3 kelas, 3 mapel)', '2026-01-23 01:42:40'),
(517, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Mapel 1 - Kelas 2 (aa) | Tanggal: - → 15 Jan 2026 | Status:  → in_progress | Deskripsi diubah', '2026-01-23 01:48:20'),
(518, 'A01', 'Files', 'CREATE', 'Upload file: 444', '2026-01-23 01:49:06'),
(519, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Mapel 1 - Kelas 2 (aa) | Tanggal: 15 Jan 2026 → - | Status: completed →  | Deskripsi diubah', '2026-01-23 01:49:20'),
(520, 'A01', 'Files', 'DELETE', 'Menghapus file: 444', '2026-01-23 01:53:41'),
(521, 'A01', 'Files', 'DELETE', 'Menghapus file: 111', '2026-01-23 01:53:42'),
(522, 'A01', 'Files', 'DELETE', 'Menghapus file: 43', '2026-01-23 01:53:44'),
(523, 'A01', 'Files', 'CREATE', 'Upload file: za', '2026-01-23 01:54:26'),
(524, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Mapel 2 - Kelas 1 (aa) | Tanggal: - → 02 Jan 2026 | Status:  → in_progress | Deskripsi diubah', '2026-01-23 01:54:43'),
(525, 'A01', 'Files', 'CREATE', 'Upload file: ppqqq', '2026-01-23 01:55:06'),
(526, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Mapel 2 - Kelas 1 (aa) | Tanggal: 02 Jan 2026 → - | Status: completed →  | Deskripsi diubah', '2026-01-23 01:55:17'),
(527, 'A01', 'Schedule', 'DELETE', 'Menghapus seluruh jadwal dan file sekolah aa', '2026-01-23 02:02:21'),
(528, 'A01', 'Schedule', 'DELETE', 'Menghapus seluruh jadwal dan file sekolah sss', '2026-01-23 02:02:25'),
(529, 'A01', 'Schedule', 'DELETE', 'Menghapus seluruh jadwal dan file sekolah Immanuel', '2026-01-23 02:02:30'),
(530, 'A01', 'Schedule', 'CREATE', 'Menambahkan jadwal baru untuk sekolah Immanuel (3 kelas, 3 mapel)', '2026-01-23 02:02:40'),
(531, 'A01', 'Schedule', 'UPDATE', 'Edit jadwal Immanuel (Jumlah kelas: 3 → 6 | Jumlah mapel: 3 → 6)', '2026-01-23 02:02:46'),
(532, 'A01', 'Schedule', 'UPDATE', 'Mengubah nama mapel di sekolah Immanuel dari Mapel 1 menjadi Bahasa Indonesia', '2026-01-23 02:02:54'),
(533, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Bahasa Indonesia - Kelas 1 (Immanuel) | Tanggal: - → 08 Jan 2026 | Status:  → not_started | Deskripsi diubah', '2026-01-23 02:03:04'),
(534, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Bahasa Indonesia - Kelas 2 (Immanuel) | Tanggal: - → 09 Jan 2026 | Status:  → in_progress | Deskripsi diubah', '2026-01-23 02:03:15'),
(535, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Bahasa Indonesia - Kelas 3 (Immanuel) | Tanggal: - → 13 Jan 2026 | Status:  → in_progress | Deskripsi diubah', '2026-01-23 02:03:27'),
(536, 'A01', 'Files', 'CREATE', 'Upload file: kelas 3', '2026-01-23 02:03:50'),
(537, 'A01', 'Files', 'CREATE', 'Upload file: kelas 1', '2026-01-23 02:04:10'),
(538, 'A01', 'Schedule', 'UPDATE', 'Update jadwal Bahasa Indonesia - Kelas 1 (Immanuel) | Tanggal: 08 Jan 2026 → - | Status: completed →  | Deskripsi diubah', '2026-01-23 02:04:28');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `user_id` varchar(6) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','guru') NOT NULL,
  `photo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`user_id`, `name`, `username`, `password`, `role`, `photo`) VALUES
('A01', 'Wendy', 'Wendy', '$2y$10$2U1mbH9YTdLIU3EUrRPGWuvNinwjHSp6UAkrv3dx9Wbfh46onf2bK', 'admin', 'profile.png'),
('G01', 'Daven', 'Daven', '$2y$10$/axMmTRzbIMkHWvsfJMdnuRSk9TPFuuBC0Qjbq2jnneQYUieGLmCG', 'guru', 'profile.png'),
('G02', 'Mars', 'Mars', '$2y$10$ycXibhPyl/wOUzs.WBQy9.Lo19ySsASsgYq9LARfchCfLUYmN2ZYq', 'guru', 'profile.png');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `file_soal`
--
ALTER TABLE `file_soal`
  ADD PRIMARY KEY (`id_soal`);

--
-- Indeks untuk tabel `jadwal_ulangan`
--
ALTER TABLE `jadwal_ulangan`
  ADD PRIMARY KEY (`id_jadwal`);

--
-- Indeks untuk tabel `log_perubahan`
--
ALTER TABLE `log_perubahan`
  ADD PRIMARY KEY (`id_perubahan`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `jadwal_ulangan`
--
ALTER TABLE `jadwal_ulangan`
  MODIFY `id_jadwal` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3362;

--
-- AUTO_INCREMENT untuk tabel `log_perubahan`
--
ALTER TABLE `log_perubahan`
  MODIFY `id_perubahan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=539;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
