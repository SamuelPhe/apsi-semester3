<?php
$koneksi = mysqli_connect("localhost", "root", "", "edusched");

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
