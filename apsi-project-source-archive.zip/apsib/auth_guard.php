<?php
// WAJIB ADA


/* ======================
   CEK SUDAH LOGIN ATAU BELUM
   ====================== */
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: login.php");
    exit;
}

/* ======================
   AUTHORIZATION BERDASARKAN ROLE
   ====================== */
function onlyAdmin() {
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
        header("Location: index.php?menu=schedule");
        exit;
    }
}

function onlyGuru() {
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'guru') {
        header("Location: index.php?menu=dashboard");
        exit;
    }
}
